<script>


    import { page } from '$app/stores';
    import { goto } from '$app/navigation';

    import { Alert, Button } from "flowbite-svelte";

    let nombreApp = $state("");

    async function inicio() {
        let nombre = await Neutralino.window.getTitle();
        nombreApp = `Nombre de la app es ${nombre}.`;
    }
    inicio();

    async function nodejs_events (e) {
        console.log("NODEJS EVENT: " + e.detail );
    }

    Neutralino.events.on("saludo", nodejs_events);
    NODE.run('hola','hola desde svelte');

    let contador = $state(0);

    let parametro = $state("");
    parametro = (new URLSearchParams(location.hash.split("?")[1])).get("aa") ?? ""; 

</script>

<h1>Pagina 2</h1>
<p>Parametro recibido: {parametro}</p>

<div class="p-8">
  <Alert>
    <span class="font-medium">Alerta:</span>
    {nombreApp}
  </Alert>
</div>

<Button onclick={() => { goto(`/#/`); }} >goto Ver pagina 1</Button>

<Button onclick={() => { window.location.href = '/#/'; }} >window.location.href Ver pagina 1</Button>

<Button onclick={() => { contador++ }} >Sumar {contador}</Button>