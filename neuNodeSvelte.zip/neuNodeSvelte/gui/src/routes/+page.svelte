<script>

    import { page } from '$app/stores';
    import { goto } from '$app/navigation';

    import { Alert, Button } from "flowbite-svelte";

    let nombreApp = $state("");

    async function inicio() {
        let nombre = await Neutralino.window.getTitle();
        nombreApp = `Nombre de la app es ${nombre}.`;
    }
    inicio();

    async function nodejs_events (e) {
        console.log("NODEJS EVENT: " + e.detail );
    }

    Neutralino.events.on("saludo", nodejs_events);
    NODE.run('hola','hola desde svelte');

    let contador = $state(0);

</script>

<div class="p-8">
  <Alert>
    <span class="font-medium">Alerta:</span>
    {nombreApp}
  </Alert>
</div>

<Button onclick={() => { goto(`/#/page2?aa=${encodeURI("hola como vas")}`); }} >goto Ver pagina 2</Button>

<Button onclick={() => { window.location.href = `/#/page2?aa=${encodeURI("hola como vas")}`; }} >window.location.href Ver pagina 2</Button>

<Button onclick={() => { contador++ }} >Sumar {contador}</Button>
