<script>

    import { Alert, Button } from "flowbite-svelte";

    let nombreApp = $state("");

    async function inicio() {
        let nombre = await Neutralino.window.getTitle();
        nombreApp = `Nombre de la app es ${nombre}.`;
    }
    inicio();

    async function nodejs_events (e) {
        console.log("NODEJS EVENT: " + e.detail );
    }

    Neutralino.events.on("saludo", nodejs_events);
    NODE.run('hola','hola desde svelte');

    let contador = $state(0);

</script>

<div class="p-8">
  <Alert>
    <span class="font-medium">Alerta:</span>
    {nombreApp}
  </Alert>
</div>

<Button onclick={() => { contador++ }} >Sumar {contador}</Button>