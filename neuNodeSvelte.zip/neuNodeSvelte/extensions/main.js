
// main.js 1.0.3
// Neutralino NodeExtension.
// (c)2023-2024 Harald Schneider - marketmix.com
// edited by: IvanJRCH - https://github.com/IvanJRCH

const NeutralinoExtension = require('./neutralino-extension');
const DEBUG = true;     // Print incoming event messages to the console

function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

function processAppEvent(d) {
    // Handle Neutralino app events.
    // :param d: data package as JSON dict.
    // :return: ---

    if(ext.isEvent(d, 'runNode')) {
        switch(d.data.function) {
        case "hola":
            ext.sendMessage('saludo', `hola desde nodejs, me dijiste: ${d.data.parameter}`);
        break;
        }
    }
}

// Activate Extension
const ext = new NeutralinoExtension(DEBUG);
console.log('---')
console.log('NodeJS Version:', process.version);
console.log('NodeJS Path:', process.execPath);
console.log('---')
ext.run(processAppEvent);
