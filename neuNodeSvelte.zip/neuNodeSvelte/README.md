# neutralinojs-zero
An empty Neutralinojs app, extend as you wish

```
neu create myapp --template neutralinojs/neutralinojs-zero
```
